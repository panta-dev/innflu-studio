/**
 * Innflu Sender — Módulo de Envio de DM com Simulação Humana,
 * Validação Estrita de Envio, Suporte a React 18 e Tratamento de Convites
 */
window.InnfluSender = {

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  },

  randomDelay(minMs, maxMs) {
    return Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;
  },

  /**
   * Verifica se apareceu algum aviso de "Ação Bloqueada" ou checkpoint do Instagram
   */
  checkActionBlock() {
    const dialogs = document.querySelectorAll('div[role="dialog"], div[role="alertdialog"], .x1n2onr6');
    for (const el of dialogs) {
      if (el.closest('#innflu-hud-root')) continue;
      const content = (el.innerText || '').toLowerCase();
      if (
        content.includes('ação bloqueada') ||
        content.includes('bloqueamos temporariamente') ||
        content.includes('tente novamente mais tarde') ||
        content.includes('action blocked') ||
        content.includes('try again later') ||
        content.includes('restringimos determinadas atividades') ||
        content.includes('we restrict certain activity') ||
        content.includes('confirm that you own this account') ||
        content.includes('confirme que esta conta é sua') ||
        content.includes('não foi possível enviar a mensagem') ||
        content.includes('failed to send')
      ) {
        return { blocked: true, message: el.innerText.trim() };
      }
    }

    const toasts = document.querySelectorAll('div[role="status"], div[aria-live="polite"], div[aria-live="assertive"]');
    for (const toast of toasts) {
      if (toast.closest('#innflu-hud-root')) continue;
      const txt = (toast.innerText || '').toLowerCase();
      if (
        txt.includes('bloque') ||
        txt.includes('action blocked') ||
        txt.includes('tente mais tarde') ||
        txt.includes('não foi possível') ||
        txt.includes('couldn\'t send')
      ) {
        return { blocked: true, message: toast.innerText.trim() };
      }
    }

    return { blocked: false };
  },

  /**
   * Localiza o botão "Enviar mensagem" no perfil do Instagram
   */
  findMessageButton() {
    // 1. Foca prioritariamente no cabeçalho do perfil (<header>) dentro de <main>
    const header = document.querySelector('main header') || document.querySelector('header') || document.querySelector('main');
    if (!header) return null;

    // 2. Coleta todos os botões e links clicáveis DENTRO do cabeçalho
    const candidates = Array.from(header.querySelectorAll('button, div[role="button"], a[role="button"], a'));

    const targetKeywords = [
      'enviar mensagem',
      'mensagem',
      'message',
      'send message',
      'enviar convite',
      'send invite',
      'enviar solicitação',
      'send request'
    ];

    for (const btn of candidates) {
      if (btn.closest('#innflu-hud-root') || btn.closest('nav') || btn.closest('aside')) continue;
      // Ignora links genéricos de caixa de entrada
      if (btn.tagName === 'A' && btn.href && btn.href.includes('/direct/inbox')) continue;

      const rawText = (btn.innerText || btn.getAttribute('aria-label') || '').toLowerCase();
      const text = rawText.replace(/\s+/g, ' ').trim();

      // Não confunda com o link geral da barra lateral ("mensagens")
      if (text === 'mensagens' || text === 'messages') continue;

      const isMatch = targetKeywords.some(kw => text === kw || text.startsWith(kw) || text.includes(kw));
      if (isMatch) {
        const rect = btn.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          const parentAnchor = btn.closest('a[href*="/direct/"]');
          return parentAnchor || btn;
        }
      }
    }

    // 3. Estratégia de Proximidade: Procura o botão adjacente ao botão de Seguir/Seguindo
    const followButtons = Array.from(header.querySelectorAll('button, div[role="button"]')).filter(b => {
      const t = (b.innerText || '').toLowerCase().trim();
      return t === 'seguir' || t === 'seguindo' || t === 'follow' || t === 'following';
    });

    for (const fBtn of followButtons) {
      const parent = fBtn.parentElement?.parentElement || fBtn.parentElement;
      if (parent) {
        const siblingButtons = Array.from(parent.querySelectorAll('button, div[role="button"]')).filter(b => b !== fBtn && !b.contains(fBtn) && !fBtn.contains(b));
        for (const sBtn of siblingButtons) {
          if (sBtn.closest('#innflu-hud-root')) continue;
          const txt = (sBtn.innerText || sBtn.getAttribute('aria-label') || '').toLowerCase().trim();
          if (txt === 'mensagens' || txt === 'messages') continue;
          if (txt.includes('mensag') || txt.includes('messag') || txt.includes('convite') || txt.includes('invite')) {
            const rect = sBtn.getBoundingClientRect();
            if (rect.width > 0 && rect.height > 0) return sBtn;
          }
        }
      }
    }

    return null;
  },

  /**
   * Dispara sequência de cliques e eventos compatível com React 18
   */
  simulateClick(element) {
    if (!element) return;
    try {
      element.scrollIntoView({ behavior: 'auto', block: 'center' });
    } catch (e) {}

    const rect = element.getBoundingClientRect();
    const clientX = rect.left + rect.width / 2;
    const clientY = rect.top + rect.height / 2;

    const commonProps = {
      bubbles: true,
      cancelable: true,
      view: window,
      detail: 1,
      screenX: window.screenX + clientX,
      screenY: window.screenY + clientY,
      clientX: clientX,
      clientY: clientY,
      button: 0,
      buttons: 1,
      which: 1
    };

    element.focus();
    element.dispatchEvent(new PointerEvent('pointerover', commonProps));
    element.dispatchEvent(new PointerEvent('pointerenter', commonProps));
    element.dispatchEvent(new PointerEvent('pointerdown', commonProps));
    element.dispatchEvent(new MouseEvent('mouseover', commonProps));
    element.dispatchEvent(new MouseEvent('mousedown', commonProps));

    element.dispatchEvent(new PointerEvent('pointerup', { ...commonProps, buttons: 0 }));
    element.dispatchEvent(new MouseEvent('mouseup', { ...commonProps, buttons: 0 }));
    element.dispatchEvent(new MouseEvent('click', { ...commonProps, buttons: 0 }));

    if (typeof element.click === 'function') {
      try { element.click(); } catch (e) {}
    }

    // Se o elemento contiver um filho clicável interno do React, despacha também
    const innerClickable = element.querySelector('div, span, button');
    if (innerClickable && innerClickable !== element) {
      try {
        innerClickable.dispatchEvent(new MouseEvent('click', { ...commonProps, buttons: 0 }));
      } catch (e) {}
    }
  },

  /**
   * Clica e abre o chat do Direct
   */
  async openDirectChat(element) {
    if (!element) return;

    // Se possui href com direct, navega ou clica na âncora
    const anchor = element.closest('a') || (element.tagName === 'A' ? element : null) || element.querySelector('a');
    if (anchor && anchor.href && anchor.href.includes('/direct/') && !anchor.href.includes('/direct/inbox')) {
      console.log('[Innflu] Abrindo Direct via link:', anchor.href);
      try { anchor.click(); } catch (e) {}
      await this.sleep(1500);
      if (window.location.pathname.startsWith('/direct/')) {
        return;
      }
      window.location.href = anchor.href;
      return;
    }

    this.simulateClick(element);
    await this.sleep(this.randomDelay(200, 400));
  },

  /**
   * Aguarda a caixa de texto legítima do Direct aparecer no DOM
   */
  async waitForMessageInput(timeoutMs = 15000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const candidates = Array.from(document.querySelectorAll(
        'div[contenteditable="true"], textarea, div[role="textbox"][contenteditable="true"]'
      ));

      for (const el of candidates) {
        if (el.closest('#innflu-hud-root')) continue;
        const rect = el.getBoundingClientRect();
        if (rect.width > 50 && rect.height > 15) {
          const aria = (el.getAttribute('aria-label') || '').toLowerCase();
          const placeholder = (el.getAttribute('placeholder') || '').toLowerCase();
          const role = (el.getAttribute('role') || '').toLowerCase();

          if (
            window.location.pathname.toLowerCase().includes('/direct/') ||
            aria.includes('mensag') || aria.includes('messag') || aria.includes('convite') || aria.includes('invite') ||
            placeholder.includes('mensag') || placeholder.includes('messag') ||
            role === 'textbox' ||
            el.getAttribute('data-lexical-editor') === 'true'
          ) {
            return el;
          }
        }
      }

      await this.sleep(300);
    }
    return null;
  },

  /**
   * Digita a mensagem no editor do Instagram com suporte nativo ao Lexical
   */
  async typeMessageIntoReact(inputEl, text) {
    inputEl.focus();
    await this.sleep(this.randomDelay(200, 350));

    // 1. Colapsa seleção dentro do input
    try {
      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(inputEl);
      range.collapse(false);
      sel.removeAllRanges();
      sel.addRange(range);
    } catch (e) {}

    // 2. Método primordial para Lexical/DraftJS: document.execCommand('insertText')
    let inserted = false;
    try {
      inserted = document.execCommand('insertText', false, text);
    } catch (e) {
      inserted = false;
    }

    // 3. Fallback estruturado para Lexical se execCommand falhar
    if (!inserted || !(inputEl.innerText || '').trim()) {
      console.log('[Innflu] Fallback para inserção estruturada no Lexical...');
      try {
        const safeText = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
        inputEl.innerHTML = `<p class="xat24cr xdj266r xdpxx8g" dir="ltr"><span data-lexical-text="true">${safeText}</span></p>`;
      } catch (e) {
        inputEl.innerText = text;
      }

      try {
        inputEl.dispatchEvent(new InputEvent('beforeinput', {
          bubbles: true,
          cancelable: true,
          inputType: 'insertText',
          data: text
        }));
        inputEl.dispatchEvent(new InputEvent('input', {
          bubbles: true,
          cancelable: true,
          inputType: 'insertText',
          data: text
        }));
      } catch (e) {}
    }

    inputEl.dispatchEvent(new Event('input', { bubbles: true }));
    inputEl.dispatchEvent(new Event('change', { bubbles: true }));
    await this.sleep(this.randomDelay(400, 600));

    if (!(inputEl.innerText || '').trim()) {
      throw new Error('Falha ao inserir texto no campo de mensagem');
    }
  },

  /**
   * Clica no botão "Enviar" ou "Enviar convite" e despacha tecla Enter
   */
  async submitMessage(inputEl) {
    await this.sleep(this.randomDelay(300, 600));

    // 1. Procura o botão Enviar / Send / Enviar convite
    const allButtons = Array.from(document.querySelectorAll('button, div[role="button"]'));
    let sendBtn = allButtons.find(b => {
      if (b.closest('#innflu-hud-root')) return false;
      const t = (b.innerText || b.getAttribute('aria-label') || '').toLowerCase().trim();
      const rect = b.getBoundingClientRect();
      const isVisible = rect.width > 0 && rect.height > 0;
      const isSendText = t === 'enviar' || t === 'send' || t === 'enviar mensagem' || t === 'enviar convite' || t === 'send invite';
      return isSendText && isVisible;
    });

    if (!sendBtn && inputEl) {
      const container = inputEl.closest('form') || inputEl.closest('div[role="region"]') || inputEl.parentElement?.parentElement?.parentElement;
      if (container) {
        const buttonsInside = Array.from(container.querySelectorAll('button, div[role="button"]')).filter(b => {
          if (b.closest('#innflu-hud-root') || b === inputEl || b.contains(inputEl)) return false;
          const rect = b.getBoundingClientRect();
          return rect.width > 0 && rect.height > 0;
        });
        if (buttonsInside.length > 0) {
          sendBtn = buttonsInside[buttonsInside.length - 1];
        }
      }
    }

    if (sendBtn) {
      console.log('[Innflu] Clicando no botão de envio:', sendBtn.innerText || sendBtn.getAttribute('aria-label') || 'Botão');
      this.simulateClick(sendBtn);
      await this.sleep(500);
    }

    // 2. Dispara tecla Enter como garantia com sequência completa de eventos
    inputEl.focus();
    const enterProps = {
      key: 'Enter',
      code: 'Enter',
      keyCode: 13,
      which: 13,
      charCode: 13,
      bubbles: true,
      cancelable: true,
      view: window
    };
    inputEl.dispatchEvent(new KeyboardEvent('keydown', enterProps));
    inputEl.dispatchEvent(new KeyboardEvent('keypress', enterProps));
    inputEl.dispatchEvent(new KeyboardEvent('keyup', enterProps));
    await this.sleep(700);
  },

  /**
   * VERIFICAÇÃO CRUCIAL: Confirma se a mensagem foi REALMENTE enviada
   * (Não prossegue para o descanso anti-ban sem confirmação positiva)
   */
  async waitForSendConfirmation(inputEl, sentText, timeoutMs = 8000) {
    const start = Date.now();
    const prefix = (sentText || '').substring(0, 20).toLowerCase().trim();

    while (Date.now() - start < timeoutMs) {
      // 1. Checa se houve bloqueio pós-clique
      const blockCheck = this.checkActionBlock();
      if (blockCheck.blocked) {
        return { confirmed: false, blocked: true, message: blockCheck.message };
      }

      // 2. Critério 1: O campo de texto foi limpo pelo React (indica que a mensagem foi despachada)
      const inputRemaining = (inputEl.innerText || '').trim();
      const inputCleared = inputRemaining.length === 0 || inputRemaining === '\n';

      // 3. Critério 2: A mensagem apareceu na lista de mensagens do chat
      const chatMessages = Array.from(document.querySelectorAll('div[role="row"], div[dir="auto"], span.x193iq5w'));
      const textFoundInThread = chatMessages.some(el => {
        if (el.closest('#innflu-hud-root') || el === inputEl || el.contains(inputEl)) return false;
        const msgContent = (el.innerText || '').toLowerCase();
        return prefix && msgContent.includes(prefix);
      });

      // 4. Critério 3: Aviso de convite enviado na tela
      const pageText = document.body.innerText.toLowerCase();
      const inviteSent = (
        pageText.includes('convite enviado') ||
        pageText.includes('invite sent') ||
        pageText.includes('você enviou um convite') ||
        pageText.includes('you sent an invite') ||
        pageText.includes('solicitação de mensagem enviada')
      );

      if (inputCleared || textFoundInThread || inviteSent) {
        console.log('[Innflu] Confirmação de envio validada:', { inputCleared, textFoundInThread, inviteSent });
        return { confirmed: true };
      }

      // Retry intermediário no meio do tempo (se o botão Enviar ainda estiver visível)
      if (Date.now() - start > 4000 && Date.now() - start < 4500) {
        console.log('[Innflu] Tentando reenviar com Enter...');
        inputEl.focus();
        const enterProps = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, charCode: 13, bubbles: true, cancelable: true };
        inputEl.dispatchEvent(new KeyboardEvent('keydown', enterProps));
        inputEl.dispatchEvent(new KeyboardEvent('keyup', enterProps));
      }

      await this.sleep(400);
    }

    return { confirmed: false, message: 'A mensagem não foi confirmada pelo Instagram como enviada (o texto permaneceu no editor).' };
  },

  /**
   * Executa o fluxo completo de envio de DM para o perfil atual com confirmação estrita
   */
  /**
   * Localiza o avatar / anel de Stories da influenciadora no perfil
   */
  findStoryAvatar() {
    const header = document.querySelector('main header') || document.querySelector('header') || document.querySelector('main');
    if (!header) return null;

    // 1. Link explícito com rota /stories/
    const anchor = header.querySelector('a[href*="/stories/"]');
    if (anchor) {
      const rect = anchor.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) return anchor;
    }

    // 2. Elemento clicável que contém o canvas do anel de stories
    const canvas = header.querySelector('canvas');
    if (canvas) {
      const btn = canvas.closest('div[role="button"]') || canvas.closest('div[tabindex="0"]') || canvas.parentElement;
      if (btn) {
        const rect = btn.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) return btn;
      }
      return canvas;
    }

    // 3. Div de botão com aria-label de stories
    const storyBtn = header.querySelector([
      'div[role="button"][aria-label*="story" i]',
      'div[role="button"][aria-label*="stories" i]',
      'div[role="button"][aria-label*="história" i]',
      'div[role="button"][aria-label*="histórias" i]',
      '[aria-label*="story" i]',
      '[aria-label*="stories" i]'
    ].join(','));
    if (storyBtn) {
      const rect = storyBtn.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) return storyBtn;
    }

    // 4. Imagem do avatar no cabeçalho
    const avatarImg = header.querySelector('img[alt*="foto" i], img[alt*="profile" i], img');
    if (avatarImg) {
      const btn = avatarImg.closest('div[role="button"]') || avatarImg.closest('a') || avatarImg.parentElement;
      if (btn) {
        const rect = btn.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) return btn;
      }
    }

    return null;
  },

  /**
   * Abre o Story garantindo que o visualizador de Stories seja carregado
   * NUNCA faz window.location.assign para rota direta (evita loop de recarregamento caso não tenha stories)
   */
  async openStoryViewer(username) {
    const header = document.querySelector('main header') || document.querySelector('header') || document.querySelector('main');
    const cleanUser = (username || window.location.pathname.split('/').filter(Boolean)[0] || '').toLowerCase().replace('@', '');

    console.log(`[Innflu] Tentando abrir Stories de @${cleanUser}...`);

    // 1. Procura link explícito para /stories/
    const anchor = header ? (header.querySelector(`a[href*="/stories/${cleanUser}"]`) || header.querySelector('a[href*="/stories/"]')) : null;
    if (anchor) {
      this.simulateClick(anchor);
      await this.sleep(1500);
      if (this.isStoryViewerOpen()) return true;
    }

    // 2. Procura avatar / anel de stories e clica
    const avatarBtn = this.findStoryAvatar();
    if (avatarBtn) {
      this.simulateClick(avatarBtn);
      await this.sleep(1500);
      if (this.isStoryViewerOpen()) return true;
    }

    // 3. Se houver canvas no header, clica nele diretamente
    const canvas = header ? header.querySelector('canvas') : null;
    if (canvas) {
      this.simulateClick(canvas);
      if (canvas.parentElement) this.simulateClick(canvas.parentElement);
      await this.sleep(1500);
      if (this.isStoryViewerOpen()) return true;
    }

    // Aguarda até mais 1500ms para confirmação de abertura assíncrona do modal de stories
    for (let t = 0; t < 5; t++) {
      if (this.isStoryViewerOpen()) return true;
      await this.sleep(300);
    }

    return this.isStoryViewerOpen();
  },

  /**
   * Verifica se o visualizador de Stories está atualmente aberto na tela
   */
  isStoryViewerOpen() {
    const path = window.location.pathname.toLowerCase();
    if (path.includes('/stories/')) return true;

    // Detecta elementos exclusivos do visualizador de Stories do Instagram Web
    const storyProgress = document.querySelector('div[role="progressbar"], div[style*="animation"]');
    const storyDialog = document.querySelector('section._ac7v, div[role="dialog"] section, section[role="region"]');
    const storyInput = document.querySelector('textarea[placeholder*="Responder" i], textarea[placeholder*="Reply" i], input[placeholder*="Responder" i]');
    return !!(storyProgress && (storyDialog || storyInput));
  },

  /**
   * Aguarda o campo de resposta de Story aparecer e o ativa
   */
  async waitForStoryReplyInput(timeoutMs = 6000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      // 1. Clica em placeholders/botões do tipo "Responder a..." para ativar o textarea
      const clickables = Array.from(document.querySelectorAll([
        'div[role="button"][aria-label*="Responder" i]',
        'div[role="button"][aria-label*="Reply" i]',
        'div[role="button"][aria-label*="Enviar mensagem" i]',
        'div[role="button"][aria-label*="Send message" i]',
        'div[tabindex="0"][aria-label*="Responder" i]',
        'div[tabindex="0"][aria-label*="Reply" i]'
      ].join(',')));

      for (const btn of clickables) {
        if (btn.closest('#innflu-hud-root')) continue;
        const rect = btn.getBoundingClientRect();
        if (rect.width > 20 && rect.height > 15 && rect.bottom > window.innerHeight * 0.3) {
          this.simulateClick(btn);
          await this.sleep(300);
          break;
        }
      }

      // 2. Procura textarea ou input ativo no Story
      const candidates = Array.from(document.querySelectorAll([
        'textarea[placeholder*="Responder" i]',
        'textarea[placeholder*="Reply" i]',
        'textarea[placeholder*="Enviar" i]',
        'textarea[placeholder*="Send" i]',
        'textarea[aria-label*="Responder" i]',
        'textarea[aria-label*="Reply" i]',
        'input[placeholder*="Responder" i]',
        'input[placeholder*="Reply" i]',
        'div[contenteditable="true"][role="textbox"]',
        'div[contenteditable="true"]',
        'textarea'
      ].join(',')));

      for (const el of candidates) {
        if (el.closest('#innflu-hud-root')) continue;
        const rect = el.getBoundingClientRect();
        // Ignora campos de busca / comentário que não são a resposta do Story
        const hint = ((el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('placeholder') || '')).toLowerCase();
        if (hint.includes('pesquis') || hint.includes('search') || hint.includes('comentá') || hint.includes('comment')) continue;
        // O input do story fica na metade inferior da tela
        if (rect.width > 40 && rect.height > 15 && rect.bottom > window.innerHeight * 0.3) {
          return el;
        }
      }

      await this.sleep(300);
    }
    return null;
  },

  /**
   * Insere o texto da mensagem no campo de resposta do Story de forma limpa (sem duplicar!)
   */
  async typeMessageIntoStoryInput(inputEl, text) {
    inputEl.focus();
    await this.sleep(200);

    const isTextarea = inputEl.tagName === 'TEXTAREA';
    const isInput = inputEl.tagName === 'INPUT';

    if (isTextarea || isInput) {
      // Resposta de Story é de linha única: junta as quebras de linha
      text = (text || '').replace(/\s*\n+\s*/g, ' ').trim();

      // 1) Método preferido: inserção "real" (dispara os eventos nativos que o React escuta)
      let typedOk = false;
      try {
        inputEl.focus();
        inputEl.select();
        document.execCommand('insertText', false, text);
        typedOk = (inputEl.value || '').trim().length > 0;
      } catch (e) { typedOk = false; }

      if (typedOk) {
        await this.sleep(400);
        return;
      }

      // 2) Fallback: setter nativo + eventos
      inputEl.value = '';
      const proto = isTextarea ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (setter) {
        setter.call(inputEl, text);
      } else {
        inputEl.value = text;
      }

      inputEl.dispatchEvent(new Event('input', { bubbles: true }));
      inputEl.dispatchEvent(new Event('change', { bubbles: true }));

      try {
        inputEl.dispatchEvent(new InputEvent('input', {
          bubbles: true,
          cancelable: true,
          inputType: 'insertText',
          data: text
        }));
      } catch (e) {}
    } else {
      await this.typeMessageIntoReact(inputEl, text);
    }

    await this.sleep(400);
  },

  /**
   * Submete a resposta do Story com botão Enviar e tecla Enter
   */
  async submitStoryReply(inputEl) {
    inputEl.focus();
    await this.sleep(250);

    // 1. Procura botão Enviar / Send ou ícone de envio próximo ao input do Story
    const sendBtn = Array.from(document.querySelectorAll('button, div[role="button"]')).find(b => {
      if (b.closest('#innflu-hud-root') || b === inputEl) return false;
      const t = (b.innerText || b.getAttribute('aria-label') || '').toLowerCase().trim();
      const rect = b.getBoundingClientRect();
      const isVisible = rect.width > 0 && rect.height > 0 && rect.bottom > window.innerHeight * 0.3;
      const isSendText = t === 'enviar' || t === 'send' || t.includes('enviar') || t.includes('send');
      const hasSendSvg = !!b.querySelector('svg[aria-label*="Enviar" i], svg[aria-label*="Send" i]');
      return (isSendText || hasSendSvg) && isVisible;
    });

    if (sendBtn) {
      console.log('[Innflu] Clicando no botão Enviar do Story...');
      this.simulateClick(sendBtn);
      await this.sleep(500);
    }

    // 2. Dispara tecla Enter como garantia com sequência completa de eventos
    const enterProps = {
      key: 'Enter',
      code: 'Enter',
      keyCode: 13,
      which: 13,
      charCode: 13,
      bubbles: true,
      cancelable: true,
      view: window
    };
    inputEl.dispatchEvent(new KeyboardEvent('keydown', enterProps));
    inputEl.dispatchEvent(new KeyboardEvent('keypress', enterProps));
    inputEl.dispatchEvent(new KeyboardEvent('keyup', enterProps));
    await this.sleep(1200);
  },

  /**
   * Fecha o visualizador de Stories do Instagram e volta ao perfil
   */
  closeStoryViewer() {
    // 1. Botão Fechar (ícone de X ou SVG com aria-label Fechar / Close)
    const closeBtn = document.querySelector([
      'div[role="button"] svg[aria-label="Fechar"]',
      'div[role="button"] svg[aria-label="Close"]',
      'svg[aria-label="Fechar"]',
      'svg[aria-label="Close"]',
      'button[aria-label="Fechar"]',
      'button[aria-label="Close"]',
      'div[role="button"][aria-label="Fechar"]',
      'div[role="button"][aria-label="Close"]'
    ].join(','));

    if (closeBtn) {
      const btn = closeBtn.closest('div[role="button"]') || closeBtn.closest('button') || closeBtn;
      this.simulateClick(btn);
    }

    // 2. Tecla Escape
    const escProps = { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true, cancelable: true, view: window };
    document.dispatchEvent(new KeyboardEvent('keydown', escProps));
    document.dispatchEvent(new KeyboardEvent('keyup', escProps));

    // 3. Fallback de histórico
    setTimeout(() => {
      if (window.location.pathname.toLowerCase().includes('/stories/')) {
        window.history.back();
      }
    }, 400);
  },

  /**
   * Abre o Story ativo da criadora e responde diretamente com a mensagem de captação
   */
  async replyToActiveStory(messageText, username) {
    const cleanUser = (username || window.location.pathname.split('/').filter(Boolean)[0] || '').toLowerCase().replace('@', '');

    console.log(`[Innflu] Abrindo Stories de @${cleanUser} para envio de mensagem...`);
    const opened = await this.openStoryViewer(cleanUser);
    if (!opened && !this.isStoryViewerOpen()) {
      throw new Error(`Não foi possível abrir os Stories de @${cleanUser} (sem stories ativos ou privados)`);
    }

    await this.sleep(1200);

    const inputEl = await this.waitForStoryReplyInput(6000);
    if (!inputEl) {
      throw new Error(`Campo de resposta de Story não disponível para @${cleanUser} (respostas desativadas neste story)`);
    }

    console.log(`[Innflu] Digitando mensagem de captação no Story de @${cleanUser}...`);
    await this.typeMessageIntoStoryInput(inputEl, messageText);

    console.log(`[Innflu] Enviando resposta do Story para @${cleanUser}...`);
    await this.submitStoryReply(inputEl);

    // Confirma envio de verdade (antes assumia sucesso sem checar)
    const confirm = await this.waitForStoryConfirmation(inputEl, 6000);
    if (confirm.blocked) {
      throw new Error(`Instagram bloqueou a ação: ${confirm.message}`);
    }
    if (!confirm.confirmed) {
      throw new Error(confirm.message);
    }

    console.log(`[Innflu] Resposta do Story disparada. Fechando visualizador e conferindo na conversa...`);
    this.closeStoryViewer();
    await this.sleep(1200);

    const check = await this.verifyStoryReplyInThread(messageText, cleanUser);
    return { ok: true, verified: check.verified, threadInput: check.inputEl || null };
  },

  /**
   * Executa o fluxo completo de envio de DM para o perfil atual com confirmação estrita
   */
  async sendDirectMessage(messageText) {
    const preCheck = this.checkActionBlock();
    if (preCheck.blocked) {
      throw new Error(`Instagram bloqueou a ação: ${preCheck.message}`);
    }

    const curPath = window.location.pathname.toLowerCase();
    const cleanUser = curPath.split('/').filter(Boolean)[0] || '';

    // 1ª tentativa: responder ao Story ativo da influenciadora
    console.log(`[Innflu] Tentando responder ao Story de @${cleanUser}...`);
    let storyErrMsg = '';
    let openInput = null;
    try {
      const info = await this.replyToActiveStory(messageText, cleanUser);
      if (info && info.ok) {
        if (info.verified === true) {
          await this.leaveThread();
          return { success: true, viaStory: true, verified: true };
        }
        if (info.verified === null) {
          // Não há como abrir a conversa para conferir (sem botão de mensagem)
          return { success: true, viaStory: true, verified: false };
        }
        // verified === false: o Story "enviou" mas o texto NÃO apareceu na conversa
        storyErrMsg = 'a resposta do Story não apareceu na conversa';
        openInput = info.threadInput || null;
      } else {
        storyErrMsg = 'Stories não disponíveis para envio';
      }
    } catch (storyErr) {
      storyErrMsg = storyErr.message || 'erro desconhecido no Story';
      console.warn(`[Innflu] Falha ao enviar via Story: ${storyErrMsg}`);
      this.closeStoryViewer();
      await this.sleep(1200);
      // Bloqueio do Instagram: nunca insistir por outro caminho
      if (/bloque|blocked|checkpoint/i.test(storyErrMsg)) {
        throw new Error(storyErrMsg);
      }
    }

    // 2ª tentativa (fallback): enviar DM pela conversa do Direct
    console.log(`[Innflu] Story não confirmado (${storyErrMsg}). Enviando por DM direto para @${cleanUser}...`);
    try {
      const res = await this.sendViaDirect(messageText, cleanUser, openInput);
      return { success: true, viaStory: res === 'already', verified: true, storyError: storyErrMsg };
    } catch (dmErr) {
      if (/bloque|blocked|checkpoint/i.test(dmErr.message || '')) {
        throw dmErr;
      }
      throw new Error(`Story: ${storyErrMsg} | DM: ${dmErr.message}`);
    }
  },

  /**
   * Fallback: abre o chat do Direct pelo botão do perfil, digita e confirma o envio
   */
  async sendViaDirect(messageText, cleanUser, existingInput = null) {
    let inputEl = existingInput && existingInput.isConnected ? existingInput : null;

    if (!inputEl) {
      // Garante que estamos no perfil (fecha viewer de Stories se ainda estiver aberto)
      if (this.isStoryViewerOpen()) {
        this.closeStoryViewer();
        await this.sleep(1200);
      }

      if (window.location.pathname.toLowerCase().startsWith('/direct/')) {
        inputEl = await this.waitForMessageInput(5000);
      }

      if (!inputEl) {
        // Aguarda o botão de mensagem aparecer (até ~6s)
        let msgBtn = null;
        for (let i = 0; i < 20 && !msgBtn; i++) {
          msgBtn = this.findMessageButton();
          if (!msgBtn) await this.sleep(300);
        }
        if (!msgBtn) {
          throw new Error('botão "Enviar mensagem" não disponível no perfil');
        }

        await this.openDirectChat(msgBtn);
        inputEl = await this.waitForMessageInput(15000);
        if (!inputEl) {
          throw new Error('campo de mensagem do Direct não abriu');
        }
        await this.sleep(1500);
      }
    }

    // Se a mensagem já está na conversa (ex.: o Story chegou a enviar), NÃO envia de novo
    const before = this.countTextOnPage(messageText);
    if (before > 0) {
      await this.leaveThread();
      return 'already';
    }

    await this.typeMessageIntoReact(inputEl, messageText);
    await this.submitMessage(inputEl);

    const result = await this.confirmSentInThread(inputEl, messageText, before, 10000);
    if (result.blocked) {
      throw new Error(`Instagram bloqueou a ação: ${result.message}`);
    }
    if (!result.confirmed) {
      throw new Error(result.message || 'envio no Direct não confirmado');
    }

    await this.sleep(800);
    await this.leaveThread();
    return 'sent';
  },

  /**
   * Normaliza texto para comparação (sem espaços, minúsculo, só o começo da mensagem)
   */
  normalizeNeedle(text) {
    return (text || '').toLowerCase().replace(/\s+/g, '').slice(0, 28);
  },

  /**
   * Conta quantas vezes o início da mensagem aparece como TEXTO VISÍVEL na página
   * (ignora o HUD do Innflu, campos de digitação e scripts). É a prova real de que
   * a mensagem apareceu na conversa.
   */
  countTextOnPage(text) {
    const needle = this.normalizeNeedle(text);
    if (!needle) return 0;
    let acc = '';
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      const node = walker.currentNode;
      const p = node.parentElement;
      if (!p) continue;
      if (p.closest('#innflu-hud-root') || p.closest('textarea') || p.closest('[contenteditable="true"]') || p.closest('script,style,noscript')) continue;
      const t = node.nodeValue;
      if (t && t.trim()) acc += t;
    }
    acc = acc.toLowerCase().replace(/\s+/g, '');
    let count = 0, idx = 0;
    while ((idx = acc.indexOf(needle, idx)) !== -1) { count++; idx += needle.length; }
    return count;
  },

  /**
   * Confirma envio no Direct: só vale se o TEXTO aparecer na conversa
   * (campo esvaziado sozinho NÃO é prova de envio)
   */
  async confirmSentInThread(inputEl, text, countBefore = 0, timeoutMs = 10000) {
    const start = Date.now();
    let retried = false;
    while (Date.now() - start < timeoutMs) {
      const blockCheck = this.checkActionBlock();
      if (blockCheck.blocked) {
        return { confirmed: false, blocked: true, message: blockCheck.message };
      }
      if (this.countTextOnPage(text) > countBefore) {
        return { confirmed: true };
      }
      if (!retried && Date.now() - start > 5000 && inputEl && inputEl.isConnected && (inputEl.innerText || inputEl.value || '').trim()) {
        retried = true;
        inputEl.focus();
        const enterProps = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, charCode: 13, bubbles: true, cancelable: true };
        inputEl.dispatchEvent(new KeyboardEvent('keydown', enterProps));
        inputEl.dispatchEvent(new KeyboardEvent('keyup', enterProps));
      }
      await this.sleep(500);
    }
    return { confirmed: false, message: 'a mensagem não apareceu na conversa do Direct (não foi enviada)' };
  },

  /**
   * Analisa as mensagens da conversa aberta: separa as que NÓS enviamos (lado direito)
   * das que ELA enviou (lado esquerdo).
   */
  analyzeThreadMessages(inputEl) {
    const inputRect = inputEl.getBoundingClientRect();
    const centerX = inputRect.left + inputRect.width / 2;
    let incoming = 0, outgoing = 0;
    const rows = Array.from(document.querySelectorAll('div[role="row"]'));
    for (const row of rows) {
      if (row.closest('#innflu-hud-root') || row.contains(inputEl)) continue;
      const texts = Array.from(row.querySelectorAll('div[dir="auto"], span[dir="auto"]')).filter(el => {
        const t = (el.innerText || '').trim();
        if (!t) return false;
        // só o elemento mais interno (evita contar o mesmo balão várias vezes)
        return !el.querySelector('div[dir="auto"], span[dir="auto"]');
      });
      for (const el of texts) {
        const r = el.getBoundingClientRect();
        if (r.width < 5 || r.height < 5) continue;
        const cx = r.left + r.width / 2;
        if (cx < centerX - 40) incoming++;
        else if (cx > centerX + 40) outgoing++;
      }
    }
    return { hasIncoming: incoming > 0, hasOutgoing: outgoing > 0, incoming, outgoing };
  },

  /**
   * Abre a conversa com a influenciadora, lê quem escreveu o quê e volta ao perfil.
   * Retorna { opened, hasIncoming, hasOutgoing }
   */
  async inspectThread(cleanUser) {
    let msgBtn = null;
    for (let i = 0; i < 17 && !msgBtn; i++) {
      msgBtn = this.findMessageButton();
      if (!msgBtn) await this.sleep(300);
    }
    if (!msgBtn) return { opened: false };

    await this.openDirectChat(msgBtn);
    const inputEl = await this.waitForMessageInput(12000);
    if (!inputEl) {
      await this.leaveThread();
      return { opened: false };
    }

    // Dá tempo do histórico carregar
    await this.sleep(2800);
    const res = this.analyzeThreadMessages(inputEl);
    console.log(`[Innflu] Conversa com @${cleanUser}: ela=${res.incoming} msgs, nós=${res.outgoing} msgs`);
    await this.leaveThread();
    return { opened: true, ...res };
  },

  /**
   * Sai da conversa do Direct e volta ao perfil
   */
  async leaveThread() {
    if (window.location.pathname.toLowerCase().startsWith('/direct/')) {
      window.history.back();
      await this.sleep(1500);
    }
  },

  /**
   * Depois de responder ao Story, abre a conversa e CONFERE se a mensagem está lá.
   * Retorna { verified: true | false | null, inputEl }  (null = não foi possível verificar)
   */
  async verifyStoryReplyInThread(messageText, cleanUser) {
    // Garante que estamos de volta ao perfil
    for (let i = 0; i < 10 && window.location.pathname.toLowerCase().startsWith('/stories/'); i++) {
      if (i === 4) { window.history.back(); }
      await this.sleep(400);
    }
    if (this.isStoryViewerOpen()) {
      this.closeStoryViewer();
      await this.sleep(1200);
    }

    let msgBtn = null;
    for (let i = 0; i < 17 && !msgBtn; i++) {
      msgBtn = this.findMessageButton();
      if (!msgBtn) await this.sleep(300);
    }
    if (!msgBtn) return { verified: null };

    await this.openDirectChat(msgBtn);
    const inputEl = await this.waitForMessageInput(12000);
    if (!inputEl) return { verified: null };

    // Dá tempo da conversa carregar e procura o texto enviado
    const start = Date.now();
    while (Date.now() - start < 6500) {
      if (this.countTextOnPage(messageText) > 0) return { verified: true, inputEl };
      await this.sleep(500);
    }
    return { verified: false, inputEl };
  },

  /**
   * Confirma que a resposta do Story foi realmente enviada
   */
  async waitForStoryConfirmation(inputEl, timeoutMs = 6000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const blockCheck = this.checkActionBlock();
      if (blockCheck.blocked) {
        return { confirmed: false, blocked: true, message: blockCheck.message };
      }

      // Campo removido do DOM ou esvaziado = mensagem despachada
      if (!inputEl.isConnected) return { confirmed: true };
      const remaining = ((inputEl.value !== undefined ? inputEl.value : inputEl.innerText) || '').trim();
      if (remaining.length === 0) return { confirmed: true };

      // Retry com Enter no meio do tempo
      if (Date.now() - start > 3000 && Date.now() - start < 3500) {
        inputEl.focus();
        const enterProps = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, charCode: 13, bubbles: true, cancelable: true };
        inputEl.dispatchEvent(new KeyboardEvent('keydown', enterProps));
        inputEl.dispatchEvent(new KeyboardEvent('keyup', enterProps));
      }
      await this.sleep(400);
    }
    return { confirmed: false, message: 'resposta do Story não confirmada (texto permaneceu no campo)' };
  }
};
